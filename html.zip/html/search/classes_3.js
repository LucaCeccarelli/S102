var searchData=
[
  ['data_498',['Data',['../structns_space_invaders_1_1_data.html',1,'nsSpaceInvaders']]]
];
