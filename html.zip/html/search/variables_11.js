var searchData=
[
  ['y_914',['y',['../structns_event_1_1_mouse_click_data__t.html#a0a2e34034a5b6c8c44087966243fc261',1,'nsEvent::MouseClickData_t::y()'],['../structns_event_1_1_mouse_move_data__t.html#a9e72b2e9f3c2f68cc33391d076f2c446',1,'nsEvent::MouseMoveData_t::y()']]]
];
