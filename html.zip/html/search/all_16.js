var searchData=
[
  ['x_477',['x',['../structns_event_1_1_mouse_click_data__t.html#a57f8fe6b3c3fb74e0d657158fb24010e',1,'nsEvent::MouseClickData_t::x()'],['../structns_event_1_1_mouse_move_data__t.html#a5093f057977a7d290ead30266c6599fb',1,'nsEvent::MouseMoveData_t::x()']]]
];
