var searchData=
[
  ['vec2d_468',['Vec2D',['../classns_graphics_1_1_vec2_d.html',1,'nsGraphics::Vec2D'],['../classns_graphics_1_1_vec2_d.html#a4a2fdd532ded3c29b7a3bd6e5a23fadf',1,'nsGraphics::Vec2D::Vec2D(const int &amp;x=0, const int &amp;y=0)'],['../classns_graphics_1_1_vec2_d.html#ae409c698404abced934b589d58513767',1,'nsGraphics::Vec2D::Vec2D(const Vec2D &amp;pos)']]],
  ['vec2d_2ecpp_469',['vec2d.cpp',['../vec2d_8cpp.html',1,'']]],
  ['vec2d_2eh_470',['vec2d.h',['../vec2d_8h.html',1,'']]],
  ['verticalalignment_471',['VerticalAlignment',['../classns_gui_1_1_text.html#a3b0b5071a55982d5612c457a832f80fa',1,'nsGui::Text']]]
];
