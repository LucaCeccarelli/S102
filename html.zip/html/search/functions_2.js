var searchData=
[
  ['bgtext_608',['BgText',['../class_bg_text.html#af1a6d5aba1d7276d6527cc1833d57dfa',1,'BgText::BgText(const nsGraphics::Vec2D &amp;position, const std::string &amp;content, const nsGraphics::RGBAcolor &amp;textColor, const nsGraphics::RGBAcolor &amp;backgroundColor)'],['../class_bg_text.html#af1a6d5aba1d7276d6527cc1833d57dfa',1,'BgText::BgText(const nsGraphics::Vec2D &amp;position, const std::string &amp;content, const nsGraphics::RGBAcolor &amp;textColor, const nsGraphics::RGBAcolor &amp;backgroundColor)']]]
];
