var indexSectionsWithContent =
{
  0: "_abcdefghiklmnoprstuvwxy~",
  1: "abcdegilmrstv",
  2: "in",
  3: "abcefgilmrstv",
  4: "_abcdefghilmoprstuvw~",
  5: "_bcdefhiklmnprstxy",
  6: "ks",
  7: "eghstv",
  8: "abfgikmstw",
  9: "o",
  10: "bftu",
  11: "emos"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "defines",
  11: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Friends",
  10: "Macros",
  11: "Pages"
};

