var searchData=
[
  ['invader_948',['INVADER',['../namespacens_entity.html#afaa5ee24c7bb0a94e2befad01fe9c267a48220d4fff5fc7e97285c5d5ce7312eb',1,'nsEntity']]],
  ['invader_5fbullet_949',['INVADER_BULLET',['../namespacens_entity.html#afaa5ee24c7bb0a94e2befad01fe9c267aea82a67bebb74f21f1ad29e52f0e5136',1,'nsEntity']]]
];
