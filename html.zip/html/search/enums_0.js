var searchData=
[
  ['entitytype_919',['EntityType',['../namespacens_entity.html#afaa5ee24c7bb0a94e2befad01fe9c267',1,'nsEntity']]],
  ['eventtype_5ft_920',['EventType_t',['../namespacens_event.html#a6e501b1114a041d127a56f51c66ada72',1,'nsEvent']]]
];
